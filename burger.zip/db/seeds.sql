INSERT INTO burgers (burger) VALUES ('Cheeseburger');
INSERT INTO burgers (burger) VALUES ('Turkey Burger');
INSERT INTO burgers (burger) VALUES ('Veggie Burger');